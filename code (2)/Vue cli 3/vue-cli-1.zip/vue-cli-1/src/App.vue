<template>
  <div class="wrapper">

    <!-- <header></header> -->

    <div class="wrapper-content">
      <section>
        <div class="container">
          <h1>HELLO</h1>
          <img alt="Vue logo" src="./assets/logo.png">
        </div>
      </section>
    </div>

    <!-- <footer></footer> -->

  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
