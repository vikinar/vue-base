/*
  Для сокетов и использвал ws - самая простая библиотека для тестов
  https://github.com/websockets/ws
  Запуск - `node server`
*/
const WebSocket = require('ws')
const comments = require('./comments.json')

const server = new WebSocket.Server({ port:3000 })

// Экземпляр параметра сокет соеденения
server.on('connection', ws => {
  // Comments
  ws.send(JSON.stringify(comments));
  // Remove comment
  ws.on('message', comment => {
    if (comment == 0 || comment == 1) {
      console.log(`Comment index = ${comment} cannot be removed`)
      return false
    }
    comments.splice(comment, 1);
    ws.send(JSON.stringify(comments));
    console.log(`Comment index = ${comment} has been removed`)
  })
})
server.onerror = error => {
  console.log(`WebSocket error: ${error}`)
}