<template lang="pug">
  .wrapper
    section
      .container
        h1.common-title Protocol Websocket
        span Status:
        span(:class="{ disabled: message==='Server is not running', online: message==='Online'}")  {{ message }}
    section(v-if="message === 'Online'")
      .container
        .comments__wrapper
          h2.common-title Comments:
          p.common-button(@click="commentsLoadnig") Refresh
          .comment(v-for="(comment, index) in comments" :key="comment.id")
            p {{ comment.title }}
            p.common-button(@click="deleteComment(index)") Delete
</template>

<script>
export default {
  async created () {
    this.$store.dispatch('checkWsServer')
      .then(() => {
        this.$store.dispatch('loadWsComments')
      })
  },
  methods: {
    deleteComment (id) {
      // eslint-disable-next-line
      console.log(id)
      this.$store.dispatch('deleteWsComment', id)
    },
    commentsLoadnig () {
      // eslint-disable-next-line
      console.log(this.$store.getters.wsComments)
      return this.$store.getters.wsComments
    },
  },
  computed: {
    message () {
      return this.$store.getters.wsMessage
    },
    comments () {
      return this.$store.getters.wsComments
    }
  },
}
</script>

<style lang="stylus" scoped>
// Server status
span
  margin-right 10px
  &:before
    display inline-block
    content '\A'
    width 10px
    height @width
    border-radius 50%
  &.disabled
    color #ff5722
    &:before
      background #ff5722
  &.online
    color #8bc34a
    &:before
      background #8bc34a

// Comments
.comments__wrapper
  margin 0 auto
  max-width 900px
  text-align center

.comment
  display flex
  align-items center
  justify-content space-between
  padding 0 14px
  margin-bottom 30px
  transition: .6s;
  border 1px solid #f2f2f2
  border-radius 8px
  box-shadow: 0 20px 20px rgba(0,0,0,.04);
  &:hover
    box-shadow: 0 20px 20px rgba(0,0,0,.06);

</style>
