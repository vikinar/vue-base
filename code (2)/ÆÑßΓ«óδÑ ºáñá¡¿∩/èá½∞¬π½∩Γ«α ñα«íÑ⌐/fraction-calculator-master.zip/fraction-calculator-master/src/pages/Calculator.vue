<template lang="pug">
  .wrapper
    section
      .container
        //- За основу и для проверки пользовался - http://calc.by/math-calculators/fraction-calculator.html
        h1.common-title Calculator
        p(v-if="errorMessage") {{ errorMessage }}
        .fraction__wrapper
          //- All fractions (in store)
          .fraction-item.fraction-added(v-for="fraction in fractions" :key="fraction.id")
            .fraction
              input(type="number" v-model="fraction.numerator" @change="refreshFraction(fraction)")
              input(type="number" v-model="fraction.denominator" @change="refreshFraction(fraction)")
            .operator(v-if="fraction.operator")
              select(v-model="fraction.operator" @change="refreshFraction(fraction)")
                option(v-for="operator in operators")
                  option {{ operator }}
          //- Answer
          .fraction-item.fraction-item--result
            .operator
              span =
            .fraction
              input(type="number" :value="answer.fraction.n" readonly)
              input(type="number" :value="answer.fraction.d" readonly)
          //- Answer (string)
          .fraction-item.fraction-item--result
            .operator
              span =
            .fraction
              span {{ answer.string }}
        //- Buttons
        span.common-button(@click="newFraction") Add fraction
        span.common-button(@click="result") Refresh
</template>
<script>
export default {
  data () {
    return {
      errorMessage: null
    }
  },
  // Изначально я хотел подвесть изменения на воч. В данном случае проще отслеживать через change. Тк при воче нужно было бы вытаскивать из стора дроби
  watch: {},
  created () {
    this.$store.dispatch('resultFraction')
  },
  computed: {
    operators () {
      return this.$store.getters.operators
    },
    // Массив со всеми дробями
    fractions () {
      return this.$store.getters.fractions
    },
    // Итоговый ответ
    answer () {
      return this.$store.getters.resultFraction
    }
  },
  methods: {
    newFraction () {
      let fraction = {
        // Имитация сервера
        id: Math.random(),
        numerator: 2,
        denominator: 1,
        operator: '+'
      }
      this.$store.dispatch('newFraction', fraction)
      .then(() => {
        this.$store.dispatch('resultFraction')
      })
    },
    result () {
      this.$store.dispatch('resultFraction')
    },
    refreshFraction (fraction) {
      // Validate
      if (fraction.numerator == '' || fraction.denominator == '') {
        this.errorMessage = 'Numerator or denominator can`t be blank'
        return false
      }
      else if (fraction.numerator <= 0 || fraction.denominator <= 0) {
        this.errorMessage = 'Numerator or denominator can`t be less than 0'
        return false
      }
      this.errorMessage = null

      this.$store.dispatch('refreshFraction', fraction)
        .then(() => {
          this.$store.dispatch('resultFraction')
        })
        .catch(err => {
          console.log(err.message)
        })
    }
  }
}
</script>

<style lang="stylus" scoped>
input
  width 60px
  height @width
  font-size 18px
  text-align center

.fraction__wrapper
  display flex
  align-items center
  flex-wrap wrap

.fraction-item
  display flex
  align-items center
  justify-content space-between
  margin 0 10px
  padding 6px
  .operator
    margin-left 30px
  &.fraction-added
    border 1px solid #f2f2f2
  &.fraction-item--result
    justify-content space-between
    .operator
      margin-left unset
      margin-right 20px
    span
      font-size 26px

.fraction
  display flex
  flex-direction column
  input
    &:first-child
      margin-bottom 8px

</style>
