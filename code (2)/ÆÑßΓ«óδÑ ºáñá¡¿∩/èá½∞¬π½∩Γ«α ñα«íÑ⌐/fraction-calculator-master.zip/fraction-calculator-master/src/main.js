import Vue from 'vue'
import App from './App.vue'

import router from './routers'
import store from './store'

// stylus - потому что он лучше всех сочетается с пагом, на командных проектах я использую SASS
import './assets/stylus/main.styl'

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
