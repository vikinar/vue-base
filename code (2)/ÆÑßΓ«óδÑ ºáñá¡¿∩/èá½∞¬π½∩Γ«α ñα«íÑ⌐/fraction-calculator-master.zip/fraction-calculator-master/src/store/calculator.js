// Я использовал Fraction.js его алгоритм мне показался наиболее корректным, изначально хотел написать сам - но это была бы просто перепись этой библиотеки.
// https://github.com/infusion/Fraction.js/
import Fraction from 'fraction.js'

// Все названия с преф. Fraction - чтобы не было конфликтов с сторонними стейтами/мутациями и тд
export default {
  state: {
    // Удобнее хранить в стейте чтобы получить возможность к динамичной смене/добавлению
    operators: ['+','-','*','/'],
    // Имитация базы данных (у второго (в задании добавляние новой дроби слева) элемента нету оператора - он дефолтный)
    fractions: [
      { id: 0, numerator: '1', denominator: '1', res:1, operator: '+' },
      { id: 1, numerator: '1', denominator: '1', res:1},
    ],
    resultFraction: {
      fraction: null,
      string: null
    },
  },
  mutations: {
    newFraction (state, payload) {
      state.fractions.unshift(payload)
    },
    refreshFraction (state, payload) {
      // Поиск нужной дроби по айди (все изменения стейта только в мутациях)
      const fraction = state.fractions.find(f => {
        return f.id === payload.id
      })
      fraction.numerator = payload.numerator
      fraction.denominator = payload.denominator
      fraction.res = new Fraction({d: payload.denominator, n: payload.numerator})
      // console.log({res: fraction.res, n: fraction.numerator, d:fraction.denominator})
    },
    //! Result
    resultFraction (state, payload) {
      state.resultFraction.string = payload
      let res = new Fraction(payload)
      res.toFraction(true)
      state.resultFraction.fraction = res
    }
  },
  actions: {
    newFraction ({commit}, payload) {
      payload.res = new Fraction({n: payload.numerator, d: payload.denominator})
      commit('newFraction', payload)
    },
    refreshFraction ({commit}, payload) {
      commit('refreshFraction', payload)
    },
    resultFraction ({commit, getters}) {
      let fractionsArray = getters.fractions,
          result = null
      // Массив с результатом и оператором
      for (let i = 0; i < fractionsArray.length; i++) {
        switch (fractionsArray[i].operator) {
          case '+':
            result += (fractionsArray[i].res + fractionsArray[i+1].res) - (i)
            break
          case '-':
            result += (fractionsArray[i].res - fractionsArray[i+1].res) - (i)
            break
          case '*':
            result += (fractionsArray[i].res * fractionsArray[i+1].res) - (i)
            break
          case '/':
            result += (fractionsArray[i].res / fractionsArray[i+1].res) - (i)
            break
        }
      }
      // console.log(result)
      commit('resultFraction', result)
    },
  },
  getters: {
    operators (state) {
      return state.operators
    },
    fractions (state) {
      return state.fractions
    },
    resultFraction (state) {
      return state.resultFraction
    }
  }
}
