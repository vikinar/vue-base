/*
  Для сокетов и использвал ws - самая простая библиотека для тестов
  https://github.com/websockets/ws
  Запуск - `node server`
*/
const ws = new WebSocket('ws://localhost:3000')

export default {
  state: {
    wsMessage: 'Server is not running',
    wsComments: null
  },
  mutations: {
    // Common mutation to change message
    updWsMessage (state, payload) {
      state.wsMessage = payload
    },
    loadWsComments (state, response) {
      // console.log(response.data)
      state.wsComments = JSON.parse(response.data)
    },
  },
  actions: {
    // Check server
    async checkWsServer ({commit}) {
      try {
        ws.onopen = () => commit('updWsMessage', 'Online')
      } catch (error) {
        throw error
      }
    },
    // Comments load
    async loadWsComments ({dispatch, commit}) {
      await dispatch('checkWsServer')
      try {
        ws.onmessage = function (response) {
          commit('loadWsComments', response)
        }
      } catch (error) {
        throw error
      }
    },
    async deleteWsComment ({dispatch, commit}, payload) {
      // Only id
      ws.send(payload)
    },
  },
  getters: {
    wsMessage (state) {
      return state.wsMessage
    },
    wsComments (state) {
      return state.wsComments
    },
  }
}