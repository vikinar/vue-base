import Vue from 'vue'
import Vuex from 'vuex'

import calculator from './calculator'
import websocket from './websocket'

Vue.use(Vuex)

export default new Vuex.Store({
  // Модули дают расширяемость и удобство
  modules: {
    calculator,
    websocket
  }
})