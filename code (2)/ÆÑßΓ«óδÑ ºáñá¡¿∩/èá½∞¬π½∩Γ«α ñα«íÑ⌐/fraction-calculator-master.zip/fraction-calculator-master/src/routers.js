// Default
import Vue from 'vue'
import Router from 'vue-router'

// Pages
import Home from '@/pages/Home'
import Calculator from '@/pages/Calculator'
import Comments from '@/pages/Comments'

Vue.use(Router)

// Не вижу смысла выносить в отдельную папку роуты потому что их всего 3
export default new Router({
  // for gh-pages
  // mode: 'history',
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/calculator',
      name: 'calculator',
      component: Calculator
    },
    {
      path: '/comments',
      name: 'comments',
      component: Comments
    }
  ]
})