<template lang="pug">
  #app
    .wrapper
      header.navbar
        .container
          ul.navbar-list
            li.navbar-item( v-for="link in links" :key="link.title" )
              router-link.navbar-link( :to="link.url" ) {{ link.title }}
      .content-wrapper
        router-view
</template>

<script>
export default {
  data () {
    return {
      links: [
        { title: 'Home', url: '/' },
        { title: 'Calculator', url: '/calculator' },
        { title: 'Comments', url: '/comments' }
      ],
    }
  },
}
</script>

<style lang="stylus">
.navbar
  padding 20px
  text-align center

.navbar-link
  color #aaaad5
  &.router-link-exact-active
    color #4343aa

</style>
