JavaScript fraction calculator.<br/>
Supports +,-,*,/<br/>
You can add any number of fractions.<br/>
