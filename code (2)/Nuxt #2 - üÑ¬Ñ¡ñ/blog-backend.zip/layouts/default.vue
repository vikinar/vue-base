<template>
  <div class="wrapper">
    <Header />
    <nuxt />
  </div>
</template>

<script>
import Header from '~/components/system/Header.vue'
export default {
  components: { Header }
}
</script>
