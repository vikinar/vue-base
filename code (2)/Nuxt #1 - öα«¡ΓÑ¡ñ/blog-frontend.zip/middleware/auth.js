export default function (contex) {
  console.log('auth')
}