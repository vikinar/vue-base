<template>
  <div class="wrapper-content wrapper-content--fixed">
    <section>
      <div class="container">
        <h1>Example Page</h1>
      </div>
    </section>
  </div>
</template>
